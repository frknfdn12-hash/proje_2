import { Router } from "express";
import authRoutes from "./auth.routes.js";
import itemRoutes from "./items.routes.js";

const router = Router();

router.get("/health", (_req, res) => {
  res.json({ status: "ok", message: "API is running" });
});

router.use("/auth", authRoutes);
router.use("/items", itemRoutes);

export default router;
