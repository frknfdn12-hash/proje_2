import { Router } from "express";
import * as itemController from "../controllers/item.controller.js";
import { authenticate } from "../middleware/auth.js";

const router = Router();

router.use(authenticate);

router.get("/meta/categories", itemController.getCategories);
router.get("/", itemController.listItems);
router.get("/:id", itemController.getItem);
router.post("/", itemController.createItem);
router.put("/:id", itemController.updateItem);
router.delete("/:id", itemController.deleteItem);

export default router;
