import { verifyToken } from "../utils/jwt.js";

export function authenticate(req, res, next) {
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Giriş yapmanız gerekiyor." });
  }

  try {
    const payload = verifyToken(header.slice(7));
    req.user = { id: payload.id, email: payload.email, name: payload.name };
    next();
  } catch {
    return res.status(401).json({ error: "Geçersiz veya süresi dolmuş oturum." });
  }
}
