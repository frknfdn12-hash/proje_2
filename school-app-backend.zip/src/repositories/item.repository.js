import db from "../database/connection.js";

const ITEM_COLUMNS =
  "id, title, description, category, created_at, updated_at";

export function findItemsByUser(userId, { search, category } = {}) {
  let sql = `SELECT ${ITEM_COLUMNS} FROM items WHERE user_id = ?`;
  const params = [userId];

  if (category) {
    sql += " AND category = ?";
    params.push(category);
  }
  if (search) {
    sql += " AND (title LIKE ? OR description LIKE ?)";
    const term = `%${search}%`;
    params.push(term, term);
  }

  sql += " ORDER BY updated_at DESC";
  return db.prepare(sql).all(...params);
}

export function findItemById(id, userId) {
  return db
    .prepare(`SELECT ${ITEM_COLUMNS} FROM items WHERE id = ? AND user_id = ?`)
    .get(id, userId);
}

export function itemExists(id, userId) {
  return Boolean(
    db.prepare("SELECT id FROM items WHERE id = ? AND user_id = ?").get(id, userId)
  );
}

export function createItem({ userId, title, description, category }) {
  const result = db
    .prepare(
      "INSERT INTO items (user_id, title, description, category) VALUES (?, ?, ?, ?)"
    )
    .run(userId, title, description, category);

  return findItemById(result.lastInsertRowid, userId);
}

export function updateItem(id, userId, { title, description, category }) {
  db.prepare(
    "UPDATE items SET title = ?, description = ?, category = ?, updated_at = datetime('now') WHERE id = ? AND user_id = ?"
  ).run(title, description, category, id, userId);

  return findItemById(id, userId);
}

export function deleteItem(id, userId) {
  return db.prepare("DELETE FROM items WHERE id = ? AND user_id = ?").run(id, userId);
}
