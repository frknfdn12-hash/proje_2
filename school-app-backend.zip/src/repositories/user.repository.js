import db from "../database/connection.js";

export function findUserByEmail(email) {
  return db.prepare("SELECT id, name, email, password_hash FROM users WHERE email = ?").get(email);
}

export function findUserById(id) {
  return db.prepare("SELECT id, name, email, created_at FROM users WHERE id = ?").get(id);
}

export function emailExists(email) {
  return Boolean(db.prepare("SELECT id FROM users WHERE email = ?").get(email));
}

export function createUser({ name, email, passwordHash }) {
  const result = db
    .prepare("INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)")
    .run(name, email, passwordHash);

  return { id: result.lastInsertRowid, name, email };
}
