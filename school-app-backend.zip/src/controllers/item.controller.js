import * as itemService from "../services/item.service.js";

export function getCategories(_req, res) {
  res.json({ categories: itemService.getCategories() });
}

export function listItems(req, res) {
  const items = itemService.listItems(req.user.id, req.query);
  res.json({ items });
}

export function getItem(req, res) {
  const result = itemService.getItem(req.user.id, req.params.id);
  if (result.error) {
    return res.status(result.status).json({ error: result.error });
  }
  res.json({ item: result.item });
}

export function createItem(req, res) {
  const result = itemService.createItem(req.user.id, req.body);
  if (result.error) {
    return res.status(result.status).json({ error: result.error });
  }
  res.status(result.status).json({ item: result.item });
}

export function updateItem(req, res) {
  const result = itemService.updateItem(req.user.id, req.params.id, req.body);
  if (result.error) {
    return res.status(result.status).json({ error: result.error });
  }
  res.json({ item: result.item });
}

export function deleteItem(req, res) {
  const result = itemService.deleteItem(req.user.id, req.params.id);
  if (result.error) {
    return res.status(result.status).json({ error: result.error });
  }
  res.json({ message: result.message });
}
