import * as authService from "../services/auth.service.js";

export function register(req, res) {
  const result = authService.register(req.body);
  if (result.error) {
    return res.status(result.status).json({ error: result.error });
  }
  res.status(result.status).json({ user: result.user, token: result.token });
}

export function login(req, res) {
  const result = authService.login(req.body);
  if (result.error) {
    return res.status(result.status).json({ error: result.error });
  }
  res.status(result.status).json({ user: result.user, token: result.token });
}

export function getMe(req, res) {
  const result = authService.getProfile(req.user.id);
  if (result.error) {
    return res.status(result.status).json({ error: result.error });
  }
  res.json({ user: result.user });
}
