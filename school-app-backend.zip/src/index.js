import "dotenv/config";
import app from "./app.js";
import { PORT } from "./config/index.js";
import { initializeSchema } from "./database/schema.js";

initializeSchema();

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
