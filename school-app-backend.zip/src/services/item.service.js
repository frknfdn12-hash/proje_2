import { DEFAULT_CATEGORY, ITEM_CATEGORIES } from "../config/index.js";
import * as itemRepository from "../repositories/item.repository.js";

export function getCategories() {
  return ITEM_CATEGORIES;
}

export function listItems(userId, { search, category } = {}) {
  const filters = {};

  if (category && ITEM_CATEGORIES.includes(category)) {
    filters.category = category;
  }
  if (search?.trim()) {
    filters.search = search.trim();
  }

  return itemRepository.findItemsByUser(userId, filters);
}

export function getItem(userId, itemId) {
  const item = itemRepository.findItemById(itemId, userId);
  if (!item) {
    return { status: 404, error: "Not bulunamadı." };
  }
  return { status: 200, item };
}

export function createItem(userId, { title, description = "", category = DEFAULT_CATEGORY }) {
  if (!title?.trim()) {
    return { status: 400, error: "Başlık gereklidir." };
  }
  if (!ITEM_CATEGORIES.includes(category)) {
    return { status: 400, error: "Geçersiz kategori." };
  }

  const item = itemRepository.createItem({
    userId,
    title: title.trim(),
    description: description.trim(),
    category,
  });

  return { status: 201, item };
}

export function updateItem(userId, itemId, { title, description = "", category = DEFAULT_CATEGORY }) {
  if (!title?.trim()) {
    return { status: 400, error: "Başlık gereklidir." };
  }
  if (!ITEM_CATEGORIES.includes(category)) {
    return { status: 400, error: "Geçersiz kategori." };
  }
  if (!itemRepository.itemExists(itemId, userId)) {
    return { status: 404, error: "Not bulunamadı." };
  }

  const item = itemRepository.updateItem(itemId, userId, {
    title: title.trim(),
    description: description.trim(),
    category,
  });

  return { status: 200, item };
}

export function deleteItem(userId, itemId) {
  const result = itemRepository.deleteItem(itemId, userId);
  if (result.changes === 0) {
    return { status: 404, error: "Not bulunamadı." };
  }
  return { status: 200, message: "Not başarıyla silindi." };
}
