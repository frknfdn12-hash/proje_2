import bcrypt from "bcryptjs";
import * as userRepository from "../repositories/user.repository.js";
import { signToken } from "../utils/jwt.js";
import { normalizeEmail, validateEmail } from "../utils/validation.js";

export function register({ name, email, password }) {
  if (!name?.trim() || !email?.trim() || !password) {
    return { status: 400, error: "Ad, e-posta ve şifre gereklidir." };
  }
  if (!validateEmail(email)) {
    return { status: 400, error: "Geçersiz e-posta adresi." };
  }
  if (password.length < 6) {
    return { status: 400, error: "Şifre en az 6 karakter olmalıdır." };
  }

  const normalizedEmail = normalizeEmail(email);
  if (userRepository.emailExists(normalizedEmail)) {
    return { status: 409, error: "Bu e-posta ile kayıtlı bir hesap zaten var." };
  }

  const passwordHash = bcrypt.hashSync(password, 10);
  const user = userRepository.createUser({
    name: name.trim(),
    email: normalizedEmail,
    passwordHash,
  });

  return { status: 201, user, token: signToken(user) };
}

export function login({ email, password }) {
  if (!email?.trim() || !password) {
    return { status: 400, error: "E-posta ve şifre gereklidir." };
  }

  const user = userRepository.findUserByEmail(normalizeEmail(email));
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return { status: 401, error: "E-posta veya şifre hatalı." };
  }

  const publicUser = { id: user.id, name: user.name, email: user.email };
  return { status: 200, user: publicUser, token: signToken(publicUser) };
}

export function getProfile(userId) {
  const user = userRepository.findUserById(userId);
  if (!user) {
    return { status: 404, error: "Kullanıcı bulunamadı." };
  }
  return { status: 200, user };
}
